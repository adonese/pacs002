def hello():
    return "Hello from pacs008-analytics!"
