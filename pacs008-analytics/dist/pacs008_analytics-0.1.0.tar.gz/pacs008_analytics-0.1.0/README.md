# pacs008-analytics

Python handler for exporting results pacs008 analytics from apache camel.
