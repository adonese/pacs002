from fastapi import FastAPI, Request
import pandas as pd
from fastapi.responses import HTMLResponse
import json

app = FastAPI()

@app.post("/pacs008-analytics")
async def pacs008_analytics(request: Request, format: str = "html"):
    pacs008_data = await request.json()
    pacs008_df = pd.json_normalize(pacs008_data)

    total_amount = pacs008_df['CdtTrfTxInf.Amt.InstdAmt'].sum()
    currency_counts = pacs008_df['CdtTrfTxInf.Amt.InstdAmt.Ccy'].value_counts()

    analytics_results = {
        'total_amount': total_amount,
        'currency_counts': currency_counts.to_dict()
    }

    if format == "json":
        return analytics_results
    else:
        html_content = f"""
        <html>
        <head>
            <title>PACS.008 Analytics</title>
        </head>
        <body>
            <h1>PACS.008 Analytics Results</h1>
            <p>Total Amount: {total_amount}</p>
            <h2>Currency Counts:</h2>
            <ul>
                {''.join(f'<li>{currency}: {count}</li>' for currency, count in currency_counts.items())}
            </ul>
        </body>
        </html>
        """
        return HTMLResponse(content=html_content, status_code=200)